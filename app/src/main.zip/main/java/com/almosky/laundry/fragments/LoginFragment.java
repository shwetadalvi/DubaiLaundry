package com.almosky.laundry.fragments;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.almosky.laundry.Almosky;
import com.almosky.laundry.R;
import com.almosky.laundry.TabHostActivity;
import com.almosky.laundry.activity.SignupOrLoginActivity;
import com.almosky.laundry.model.Logindto;
import com.almosky.laundry.utils.AppPrefes;
import com.almosky.laundry.utils.api.ApiCalls;
import com.almosky.laundry.utils.constants.ApiConstants;
import com.almosky.laundry.utils.constants.PrefConstants;
import com.google.gson.Gson;
import com.leo.simplearcloader.SimpleArcDialog;
import com.loopj.android.http.RequestParams;

import cn.pedant.SweetAlert.SweetAlertDialog;


/**
 * A simple {@link Fragment} subclass.
 */
public class LoginFragment extends Fragment implements SignupOrLoginActivity.FragmentResultInterface {


    private static final String ARG_PAGE_NUMBER = "page_number";
    public static final int LOGIN = 2;
    private SignupOrLoginActivity SignUpActivity;
    private ApiCalls apiCalls;
    EditText email,password;


    SimpleArcDialog dialog;
    private AppPrefes appPrefes;

    public LoginFragment() {
        // Required empty public constructor
    }

    public static LoginFragment newInstance(int page) {
        LoginFragment fragment = new LoginFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_PAGE_NUMBER, page);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_login, container, false);

        SignUpActivity=(SignupOrLoginActivity)getActivity();
        SignUpActivity.setListener(this);
        apiCalls=new ApiCalls();
        appPrefes=new AppPrefes(SignUpActivity);

        email= (EditText)view. findViewById(R.id.emailEditText);
        password= (EditText)view. findViewById(R.id.passwordEditText);

        Button login=view.findViewById(R.id.btnLogin);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onLogin(v);
            }
        });



        return view;
    }

    public void onLogin(View view) {
        // if (!validate(view.getResources())) return;
        RequestParams params = new RequestParams();

        // params.put("LoginEmail", "admin@gmail.com");
        params.put(ApiConstants.email, email.getText().toString());
        params.put(ApiConstants.password, password.getText().toString());

        String url = ApiConstants.loginUrl;
        apiCalls.callApiPost(SignUpActivity, params, SignUpActivity.mDialog, url,1);
    }


    @Override
    public void fragmentResultInterface(String response, int requestId) {

        final Logindto userData;
        Gson gson = new Gson();
        userData= gson.fromJson(response, Logindto.class);
        try{




            //  JSONObject objectResponse = new JSONObject(response);
            if(userData.getStstus()){

                appPrefes.saveData(PrefConstants.email,userData.getProfile().get(0).getEmail());
                appPrefes.saveData(PrefConstants.name, userData.getProfile().get(0).getName());
               // appPrefes.saveIntData(PrefConstants.uid,userData.getProfile().get(0).getID());


                appPrefes.saveBoolData(PrefConstants.isLogin, true);
               /* new SweetAlertDialog(SignUpActivity, SweetAlertDialog.SUCCESS_TYPE)
                        .setTitleText("Success")
                        .setContentText(userData.getMessage())
                        .show();*/

                Intent i=new Intent(getActivity(), TabHostActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);

               // Intent intent = new Intent(this, Sig);

               // intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // To clean up all activities


                // intent.putExtra("finish", true);
                //intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // To clean up all activities
             //   startActivity(intent);
                // finish();

            }else{

                new SweetAlertDialog(SignUpActivity, SweetAlertDialog.ERROR_TYPE)
                        .setTitleText("Failed")
                        .setContentText(userData.getMessage())
                        .show();

            }


        }catch (Exception e){

            new SweetAlertDialog(SignUpActivity, SweetAlertDialog.ERROR_TYPE)
                    .setTitleText("Failed")
                    .setContentText(userData.getMessage())
                    .show();
            e.printStackTrace();

        }

    }
}

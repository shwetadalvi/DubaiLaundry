package com.almosky.laundry.viewholder;

import android.content.Context;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.almosky.laundry.Almosky;
import com.almosky.laundry.R;
import com.almosky.laundry.activity.AddressListActivity;
import com.almosky.laundry.model.Addressdto;

public class AddressRecyclerViewHolders extends RecyclerView.ViewHolder implements View.OnClickListener {

    private TextView textTitle;
    //    UserActionCountItemBinding binding;
    public TextView addressText;
    AddressListActivity _activty;
    ConstraintLayout adrsLyt;

    public final Context ctx;
    String address;

    Addressdto.Result addressData;


    public AddressRecyclerViewHolders(View itemView, Context context, AddressListActivity activity) {
        super(itemView);
        ctx = context;
          _activty=activity;


        addressText = itemView.findViewById(R.id.textAddress);
        textTitle = itemView.findViewById(R.id.textTitle);
        adrsLyt=itemView.findViewById(R.id.lytAddress);

        textTitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Almosky.getInst().setAddress(address);
                Almosky.getInst().setAddressId(addressData.getID());


                _activty.onClickAddress();
            }
        });

        addressText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Almosky.getInst().setAddress(address);
                Almosky.getInst().setAddressId(addressData.getID());

                _activty.onClickAddress();

            }
        });

//        binding = DataBindingUtil.bind(itemView);
    }


    public void bind(Addressdto.Result item) {
         address = "";
         addressData=item;


        if (null != item.getArea())
            if (!item.getArea().equalsIgnoreCase(""))
                if (address.length() > 0)
                    address = address + ", " + item.getArea();
                else
                    address = item.getArea();

        if (null != item.getStreet())
            if (!item.getStreet().equalsIgnoreCase(""))
                if (address.length() > 0)
                    address = address + ", " + item.getStreet();
                else
                    address = item.getStreet();
        if (null != item.getBlock())
            if (!item.getBlock().equalsIgnoreCase(""))
                if (address.length() > 0)
                    address = address + ", " + item.getBlock();
                else
                    address = item.getBlock();


        if (null != item.getHouse())
            if (!item.getHouse().equalsIgnoreCase(""))
                if (address.length() > 0)
                    address = address + ", " + item.getHouse();
                else
                    address = item.getHouse();

        if (null != item.getApartment())
            if (!item.getApartment().equalsIgnoreCase(""))
                if (address.length() > 0)
                    address = address + ", " + item.getApartment();
                else
                    address = item.getApartment();
        if (null != item.getFloor())
            if (!item.getFloor().equalsIgnoreCase(""))
                if (address.length() > 0)
                    address = address + ", " + item.getFloor();
                else
                    address = item.getFloor();

        addressText.setText(address);
        textTitle.setText(item.getAddressName());
        //   itm=item;
    }

    @Override
    public void onClick(View v) {

        _activty.onClickAddress();

    }
}

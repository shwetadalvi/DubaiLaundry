package com.almosky.laundry.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.almosky.laundry.Almosky;
import com.almosky.laundry.R;
import com.almosky.laundry.activity.neworder.CategoryListActivity;
import com.almosky.laundry.adapter.AddressListAdapter;
import com.almosky.laundry.common.BaseActivity;
import com.almosky.laundry.model.Addressdto;
import com.almosky.laundry.utils.AppPrefes;
import com.almosky.laundry.utils.api.ApiCalls;
import com.almosky.laundry.utils.constants.ApiConstants;
import com.almosky.laundry.utils.constants.PrefConstants;
import com.google.gson.Gson;
import com.leo.simplearcloader.SimpleArcDialog;
import com.loopj.android.http.RequestParams;


public class AddressListActivity extends BaseActivity {

    AppPrefes appPrefes;
    ApiCalls apiCalls;
    SimpleArcDialog dialog;
    RecyclerView rvAddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_address_list);
        Button addAddress = findViewById(R.id.addAddress);
        addAddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AddressListActivity.this, AddAddressActivity.class);
                startActivity(intent);
            }
        });

        appPrefes=new AppPrefes(this);
        dialog=new SimpleArcDialog(this);
        rvAddress=(RecyclerView)findViewById(R.id.rvaddressList);
        apiCalls=new ApiCalls();

        ImageView backButton = findViewById(R.id.backArrow);
        backButton.setVisibility(View.VISIBLE);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });



        getAddressList();


    }

    private void getAddressList() {

        // if (!validate(view.getResources())) return;
        RequestParams params = new RequestParams();

        params.put("email",  appPrefes.getData(PrefConstants.email));

        // params.put(ApiConstants.uid, appPrefes.getData(PrefConstants.uid));
        // params.put(ApiConstants.uid, 1);
        //  params.put(ApiConstants.status, "Pending");


        String url = ApiConstants.addresslistUrl;
       apiCalls.callApiPost(AddressListActivity.this, params, dialog, url, 1);




    }

    public void onClickAddress(){

      /*  if(Almosky.getInst().getAddressType().equals("1")){
            Intent go=new Intent(AddressListActivity.this,OrderConfirmationActivity.class);
            startActivity(go);
        } */

        if(Almosky.getInst().getAddressType().equals(0)){
            Intent intent = new Intent(AddressListActivity.this, AddressListActivity.class);
            startActivity(intent);
        }else {
            Intent intent = new Intent(AddressListActivity.this, CategoryListActivity.class);
            startActivity(intent);
        }
    }

    @Override
    public void getResponse(String response, int requestId) {

        try{
            Gson gson = new Gson();
            final Addressdto addressList = gson.fromJson(response, Addressdto.class);
            AddressListAdapter mAdapter = new AddressListAdapter(AddressListActivity.this, addressList.getResult(),this);
            RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
            rvAddress.setLayoutManager(mLayoutManager);
            rvAddress.setItemAnimator(new DefaultItemAnimator());
            rvAddress.setAdapter(mAdapter);


        }catch (Exception e){

        }


    }
}

package com.almosky.laundry.fragments;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.almosky.laundry.R;
import com.almosky.laundry.activity.SignupOrLoginActivity;
import com.almosky.laundry.utils.api.ApiCalls;
import com.almosky.laundry.utils.constants.ApiConstants;
import com.loopj.android.http.RequestParams;

import org.json.JSONObject;

import cn.pedant.SweetAlert.SweetAlertDialog;


/**
 * A simple {@link Fragment} subclass.
 */
public class SignUpFragment extends Fragment implements SignupOrLoginActivity.FragmentResultInterface {

    private static final String ARG_PAGE_NUMBER = "page_number";
    public static final int SIGNUP = 1;
    private SignupOrLoginActivity SignUpActivity;
    private ApiCalls apiCalls;
    EditText fname,email,password,lname,phone;

    public SignUpFragment() {
        // Required empty public constructor
    }
    public static SignUpFragment newInstance(int page) {
        SignUpFragment fragment = new SignUpFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_PAGE_NUMBER, page);
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_sign_up, container, false);
        SignUpActivity=(SignupOrLoginActivity)getActivity();
        SignUpActivity.setListener(this);
        apiCalls=new ApiCalls();

        fname=view.findViewById(R.id.edt_first_name);
        lname=view.findViewById(R.id.edt_last_name);
        email=view.findViewById(R.id.edt_email);
        password=view.findViewById(R.id.edt_password);
        phone=view.findViewById(R.id.edt_phone);

        Button register=view.findViewById(R.id.btn_create_account);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                onRegister(v);
            }
        });


        return view;
    }

    public void onRegister(View view) {
        // if (!validate(view.getResources())) return;
        RequestParams params = new RequestParams();

        // params.put("LoginEmail", "admin@gmail.com");
        params.put(ApiConstants.firstname, fname.getText().toString());
        params.put(ApiConstants.email, email.getText().toString());
        params.put(ApiConstants.password, password.getText().toString());
        params.put(ApiConstants.lastname, lname.getText().toString());
        params.put(ApiConstants.phone, phone.getText().toString());


        String url = ApiConstants.signUpUrl;
        apiCalls.callApiPost(SignUpActivity, params, SignUpActivity.mDialog, url,1);
    }


    @Override
    public void fragmentResultInterface(String response, int requestId) {
        try{
            JSONObject objectResponse = new JSONObject(response);
            if(objectResponse.getString("status").equals("true")){

                new SweetAlertDialog(SignUpActivity, SweetAlertDialog.NORMAL_TYPE)
                        .setTitleText("Success")
                        .setContentText(objectResponse.getString("Message"))
                        .setConfirmText("Ok")
                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                sDialog.dismissWithAnimation();
                               // startActivity(new Intent(SignUpActivity, Log.class));
                             //   finish();
                            }
                        })
                        .show();



            }else{

                new SweetAlertDialog(SignUpActivity, SweetAlertDialog.ERROR_TYPE)
                        .setTitleText("Failed")
                        .setContentText(objectResponse.getString("Message"))
                        .show();

            }


        }catch (Exception e){

        }
    }


}

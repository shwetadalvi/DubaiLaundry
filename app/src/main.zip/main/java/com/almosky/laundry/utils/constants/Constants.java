package com.almosky.laundry.utils.constants;


public interface Constants {
    String isHome = "isHome";
    String name="name";
    String email="email";
    String area = "area";
    String street = "street_no";
    String land = "landmark";
    String building = "building_name";
    String flat = "flat_number";
    String phone = "phone_number";
    String emirate = "emirate";
    String deldatetime = "deldate";
    String pickdatetime = "pickdate";

}

package com.almosky.laundry.activity;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;

import com.almosky.laundry.R;
import com.almosky.laundry.adapter.SignUporLoginPagerAdapter;
import com.almosky.laundry.common.BaseActivity;
import com.almosky.laundry.fragments.LoginFragment;
import com.almosky.laundry.fragments.SignUpFragment;


public class SignupOrLoginActivity  extends BaseActivity {

    private TabLayout tabLayout;
    private FragmentResultInterface listener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup_or_login_activity);
        tabLayout = findViewById(R.id.tabs);
        ViewPager pager = findViewById(R.id.pager);
        SignUporLoginPagerAdapter adapter = new SignUporLoginPagerAdapter(getSupportFragmentManager());

        pager.setAdapter(adapter);
        tabLayout.setupWithViewPager(pager);
    }


    public interface FragmentResultInterface{
        void fragmentResultInterface(String response, int requestId);
    }
    public void setListener(FragmentResultInterface fragmentResultInterface){
        this.listener = fragmentResultInterface;
    }

    @Override
    public void getResponse(String response, int requestId) {
        super.getResponse(response, requestId);
        if(requestId == SignUpFragment.SIGNUP){
            listener.fragmentResultInterface(response,requestId);
        }
        if(requestId == LoginFragment.LOGIN){
            listener.fragmentResultInterface(response,requestId);
        }

    }
}

package com.almosky.laundry.di.component;

import android.content.Context;


import com.almosky.laundry.di.module.ApplicationModule;
import com.almosky.laundry.utils.AppPrefes;
import com.almosky.laundry.utils.UtilsPref;
import com.almosky.laundry.utils.api.ApiCalls;

import javax.inject.Singleton;

import dagger.Component;


@Singleton
@Component(modules = {ApplicationModule.class})
public interface AppComponent {
    Context appContext();

    UtilsPref appUtilsPref();

    AppPrefes appAppPrefes();

    ApiCalls appApiCalls();
}

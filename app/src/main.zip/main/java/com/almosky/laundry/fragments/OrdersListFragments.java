package com.almosky.laundry.fragments;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.almosky.laundry.R;
import com.almosky.laundry.TabHostActivity;
import com.almosky.laundry.activity.SignupOrLoginActivity;
import com.almosky.laundry.adapter.OrderListAdapter;
import com.almosky.laundry.model.OrderListdto;
import com.almosky.laundry.utils.AppPrefes;
import com.almosky.laundry.utils.api.ApiCalls;
import com.almosky.laundry.utils.constants.ApiConstants;
import com.almosky.laundry.utils.constants.PrefConstants;
import com.google.gson.Gson;
import com.leo.simplearcloader.SimpleArcDialog;
import com.loopj.android.http.RequestParams;


/**
 * A simple {@link Fragment} subclass.
 */
public class OrdersListFragments extends Fragment implements TabHostActivity.FragmentResultInterface{
    AppPrefes appPrefes;
    ApiCalls apiCalls;
    SimpleArcDialog dialog;
    TabHostActivity tabHostActivity;
    RecyclerView rvOrders;

    private static final String ARG_PAGE_NUMBER = "page_number";

    public OrdersListFragments() {
        // Required empty public constructor
    }

    public static OrdersListFragments newInstance(int page) {
        OrdersListFragments fragment = new OrdersListFragments();
        Bundle args = new Bundle();
        args.putInt(ARG_PAGE_NUMBER, page);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       View view = inflater.inflate(R.layout.fragment_orderslist, container, false);
       tabHostActivity=(TabHostActivity)getActivity();
       tabHostActivity.setListener(this);
        rvOrders=(RecyclerView)view.findViewById(R.id.rvorderList);
        apiCalls=new ApiCalls();
        appPrefes=new AppPrefes(tabHostActivity);
        dialog=new SimpleArcDialog(tabHostActivity);

        if(appPrefes.getBoolData(PrefConstants.isLogin)){
            getOrders();
        }else {
            startActivity(new Intent(getActivity(), SignupOrLoginActivity.class));
        }




     /*   ConstraintLayout easyOrderLyt = (ConstraintLayout) view.findViewById(R.id.easyOrderLyt);
        easyOrderLyt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Almosky.getInst().setOrderType("easy");
                startActivity(new Intent(getActivity(), OrdertypeActivity.class));
            }
        });
        ConstraintLayout normalOrderLyt = (ConstraintLayout) view.findViewById(R.id.normalOrderLyt);
        normalOrderLyt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Almosky.getInst().setOrderType("enter");
                startActivity(new Intent(getActivity(), OrdertypeActivity.class));
            }
        });*/
        return view;
    }

    private void getOrders() {

        // if (!validate(view.getResources())) return;
        RequestParams params = new RequestParams();

        params.put("email",  appPrefes.getData(PrefConstants.email));
        params.put("status",  "All");

        // params.put(ApiConstants.uid, appPrefes.getData(PrefConstants.uid));
        // params.put(ApiConstants.uid, 1);
        //  params.put(ApiConstants.status, "Pending");


        String url = ApiConstants.orderListUrl;
        apiCalls.callApiPost(tabHostActivity, params, dialog, url, 1);


    }

    @Override
    public void fragmentResultInterface(String response, int requestId) {

        try{
            Gson gson = new Gson();
            final OrderListdto orderList = gson.fromJson(response, OrderListdto.class);
            OrderListAdapter mAdapter = new OrderListAdapter(tabHostActivity, orderList.getResult());
            RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(tabHostActivity);
            rvOrders.setLayoutManager(mLayoutManager);
            rvOrders.setItemAnimator(new DefaultItemAnimator());
            rvOrders.setAdapter(mAdapter);


        }catch (Exception e){

        }

    }
}

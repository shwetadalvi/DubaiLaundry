package com.almosky.laundry.fragments;


import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.almosky.laundry.Almosky;

import com.almosky.laundry.R;
import com.almosky.laundry.TabHostActivity;
import com.almosky.laundry.activity.AboutUsActivity;
import com.almosky.laundry.activity.AddressListActivity;
import com.almosky.laundry.activity.ContactUsActivity;
import com.almosky.laundry.activity.SignupOrLoginActivity;
import com.almosky.laundry.activity.TermsActivity;
import com.almosky.laundry.utils.AppPrefes;
import com.almosky.laundry.utils.constants.PrefConstants;


/**
 * A simple {@link Fragment} subclass.
 */
public class ProfileFragments extends Fragment {

    ImageView profile,icedit;
    TextView name,loginText,logout;
    AppPrefes appPrefes;
    RelativeLayout logoutlyt,contactLyt,terms,about;


    public ProfileFragments() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_profile_fragments, container, false);
        ConstraintLayout profileHeader = view.findViewById(R.id.profileHeader);
        RelativeLayout lyt_address = view.findViewById(R.id.lyt_address);
        profileHeader.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), SignupOrLoginActivity.class);
                startActivity(intent);
            }
        });
        lyt_address.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Almosky.getInst().setAddressType("0");
                Intent intent = new Intent(getActivity(), AddressListActivity.class);
                startActivity(intent);
            }
        });

        appPrefes =new AppPrefes(getActivity());

        name=view.findViewById(R.id.name);
        loginText=view.findViewById(R.id.textLogin);
        profile=view.findViewById(R.id.profileimage);
        logoutlyt=view.findViewById(R.id.lyt_logout);
        contactLyt=view.findViewById(R.id.lyt_contactus);
        about=view.findViewById(R.id.lyt_aboutus);
        terms=view.findViewById(R.id.lyt_terms);
        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getActivity(), AboutUsActivity.class);
                // i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
            }
        });
        terms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i=new Intent(getActivity(), TermsActivity.class);
                // i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);

            }
        });
        contactLyt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getActivity(), ContactUsActivity.class);
               // i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);

            }
        });
        icedit=view.findViewById(R.id.btnEdit);

        if(appPrefes.getBoolData(PrefConstants.isLogin)){

            loginText.setVisibility(View.INVISIBLE);
            name.setText(appPrefes.getData(PrefConstants.name));

        }else {
            name.setVisibility(View.GONE);
            profile.setVisibility(View.VISIBLE);
           // profile.setImageResource(getResources().getDrawable(R.drawable.));
            loginText.setVisibility(View.VISIBLE);
            icedit.setVisibility(View.GONE);
            lyt_address.setVisibility(View.GONE);
            logoutlyt.setVisibility(View.GONE);
        }

        logoutlyt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                appPrefes.saveData(PrefConstants.email,"");
                appPrefes.saveData(PrefConstants.name, "");
                // appPrefes.saveIntData(PrefConstants.uid,userData.getProfile().get(0).getID());

                appPrefes.saveBoolData(PrefConstants.isLogin, false);

                Intent i=new Intent(getActivity(), TabHostActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);


            }
        });

        return view;
    }

}

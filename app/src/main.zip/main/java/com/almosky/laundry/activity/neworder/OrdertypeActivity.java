package com.almosky.laundry.activity.neworder;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.almosky.laundry.Almosky;
import com.almosky.laundry.R;
import com.almosky.laundry.activity.PickUpActivity;
import com.almosky.laundry.common.BaseActivity;
import com.almosky.laundry.utils.AppPrefes;
import com.almosky.laundry.utils.api.ApiCalls;
import com.leo.simplearcloader.SimpleArcDialog;


public class OrdertypeActivity extends BaseActivity {

    private RecyclerView activeOrderRecyclerView;

    private TextView addNew, name;
    AppPrefes appPrefes;
    SimpleArcDialog dialog;
    ApiCalls apiCalls;

    public static final int ACTIVE_ORDERS = 8;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_order_type);

        appPrefes = new AppPrefes(this);
        dialog = new SimpleArcDialog(this);
        apiCalls = new ApiCalls();


        ImageView backButton = findViewById(R.id.backArrow);
        backButton.setVisibility(View.VISIBLE);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        LinearLayout normal = (LinearLayout) findViewById(R.id.lyt_normal);

        normal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Almosky.getInst().setServiceId(1);
                Intent go = new Intent(OrdertypeActivity.this, PickUpActivity.class);
                startActivity(go);
            }
        });

        LinearLayout fast = (LinearLayout) findViewById(R.id.lyt_fast);
        fast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Almosky.getInst().setServiceId(2);  //fast service
                Intent go=new Intent(OrdertypeActivity.this,PickUpActivity.class);
                startActivity(go);

            }
        });

    }


}

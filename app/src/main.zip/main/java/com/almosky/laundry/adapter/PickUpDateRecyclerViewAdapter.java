package com.almosky.laundry.adapter;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;


import com.almosky.laundry.Almosky;
import com.almosky.laundry.R;
import com.almosky.laundry.viewholder.PickUpDateRecyclerViewHolders;

import java.util.List;

public class PickUpDateRecyclerViewAdapter extends RecyclerView.Adapter<PickUpDateRecyclerViewHolders> {

    private final List<String> _dateArray;
    //    private List<UserLogCountResponse.DetailsBean> itemList;
    private Context context;
    private int row_index;
    private String _activity;


    public PickUpDateRecyclerViewAdapter(Context context, List<String> dateArray,String activity) {
//        this.itemList = itemList;
        this.context = context;
        _dateArray = dateArray;
        this._activity=activity;
    }

    @Override
    public PickUpDateRecyclerViewHolders onCreateViewHolder(ViewGroup parent, int viewType) {

        View layoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.pickup_date_item, null);
        PickUpDateRecyclerViewHolders rcv = new PickUpDateRecyclerViewHolders(layoutView, context);

        return rcv;
    }

    @Override
    public void onBindViewHolder(PickUpDateRecyclerViewHolders holder, final int position) {
//        UserLogCountResponse.DetailsBean status = itemList.get(position);
        LinearLayout rowDate = holder.itemView.findViewById(R.id.rowDate);
        TextView day = holder.itemView.findViewById(R.id.day);
        TextView date = holder.itemView.findViewById(R.id.date);
        day.setText(_dateArray.get(position));

        if(position==0) {

            if (_activity.equals("pickup")) {
                Almosky.getInst().setPickupdate(_dateArray.get(position));
            }
            if (_activity.equals("delivery")) {
                Almosky.getInst().setDeliverydate(_dateArray.get(position));
            }
        }

        rowDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                row_index = position;
                if(_activity.equals("pickup")){
                    Almosky.getInst().setPickupdate(_dateArray.get(position));
                }
                if(_activity.equals("delivery")){
                    Almosky.getInst().setDeliverydate(_dateArray.get(position));
                }

                notifyDataSetChanged();
            }
        });
        if (row_index == position) {
            rowDate.setBackgroundColor(Color.parseColor("#ff3d5afe"));
            day.setTextColor(Color.parseColor("#ffffff"));
            date.setTextColor(Color.parseColor("#ffffff"));
        } else {
            rowDate.setBackgroundColor(Color.parseColor("#ffffff"));
            day.setTextColor(Color.parseColor("#000000"));
            date.setTextColor(Color.parseColor("#000000"));
        }
//        holder.bind();
    }


    @Override
    public int getItemCount() {
//        if (null == itemList)
//            return 0;
//        else
//            return this.itemList.size();
        return _dateArray.size();
    }
}

package com.almosky.laundry.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;


import com.almosky.laundry.Almosky;
import com.almosky.laundry.R;
import com.almosky.laundry.activity.neworder.CategoryListActivity;
import com.almosky.laundry.adapter.PickUpDateRecyclerViewAdapter;
import com.almosky.laundry.adapter.PickUpTimeRecyclerViewAdapter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DeliveryActivity extends AppCompatActivity {
    private RecyclerView recyclerViewDates;
    private RecyclerView recyclerViewTimes;
    List<String> timeArray = new ArrayList<>(Arrays.asList("11:30 AM - 12:30 PM", "12:30 PM - 01:30 PM", "01:30 PM - 02:30 PM", "02:30 PM - 03:30 PM", "03:30 PM - 04:30 PM", "04:30 PM - 05:30 PM", "05:30 PM - 06:30 PM", "06:30 PM - 07:30 PM", "07:30 PM - 08:30 PM", "08:30 PM - 09:30 PM", "09:30 PM - 10:30 PM", "10:30 PM - 11:30 PM"));
    List<String> dateArray = new ArrayList<>(Arrays.asList("2018.12.20", "2018.12.21", "2018.12.23", "2018.12.25"));
    private Button btnDone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery);
        init();
    }
    private void init() {
        recyclerViewDates = (RecyclerView) findViewById(R.id.dates);
        recyclerViewTimes = (RecyclerView) findViewById(R.id.times);
        btnDone = (Button) findViewById(R.id.btnDone);
        PickUpDateRecyclerViewAdapter mAdapterDate = new PickUpDateRecyclerViewAdapter(DeliveryActivity.this,dateArray,"delivery");
        RecyclerView.LayoutManager mLayoutManagerDate = new LinearLayoutManager(getApplicationContext());
        recyclerViewDates.setLayoutManager(mLayoutManagerDate);
        recyclerViewDates.setItemAnimator(new DefaultItemAnimator());
        recyclerViewDates.setAdapter(mAdapterDate);

        PickUpTimeRecyclerViewAdapter mAdapterTime = new PickUpTimeRecyclerViewAdapter(DeliveryActivity.this,timeArray,"delivery");
        RecyclerView.LayoutManager mLayoutManagerTime = new LinearLayoutManager(getApplicationContext());
        recyclerViewTimes.setLayoutManager(mLayoutManagerTime);
        recyclerViewTimes.setItemAnimator(new DefaultItemAnimator());
        recyclerViewTimes.setAdapter(mAdapterTime);
        listeners();

        Almosky.getInst().setAddressType("1");

        Toolbar mToolbar= (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                // perform whatever you want on back arrow click
            }
        });
    }
    private void listeners() {
        btnDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(DeliveryActivity.this, AddressListActivity.class);
                startActivity(intent);
              /*  if(Almosky.getInst().getAddressType().equals("easy")){
                    Intent intent = new Intent(DeliveryActivity.this, AddressListActivity.class);
                    startActivity(intent);
                }else {
                    Intent intent = new Intent(DeliveryActivity.this, CategoryListActivity.class);
                    startActivity(intent);
                }*/

            }
        });
    }
}

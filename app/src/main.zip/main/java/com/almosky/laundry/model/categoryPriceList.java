package com.almosky.laundry.model;

import java.util.ArrayList;

public class categoryPriceList {
    String categoryName;
    public ArrayList<categoryItemPrice> categoryItemPrices;

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public ArrayList<categoryItemPrice> getCategoryItemPrices() {
        return categoryItemPrices;
    }

    public void setCategoryItemPrices(ArrayList<categoryItemPrice> categoryItemPrices) {
        this.categoryItemPrices = categoryItemPrices;
    }
}

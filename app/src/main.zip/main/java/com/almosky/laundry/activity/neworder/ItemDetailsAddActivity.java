package com.almosky.laundry.activity.neworder;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.almosky.laundry.Almosky;
import com.almosky.laundry.R;
import com.almosky.laundry.model.data;
import com.bumptech.glide.Glide;


import java.util.ArrayList;

public class ItemDetailsAddActivity extends AppCompatActivity {

    private TextView title;
    String catName,itemName;
    int itemId,catId;
    private ArrayList<data.Detail.Item> dry;
    private ArrayList<data.Detail.Item> wash;
    private ArrayList<data.Detail.Item> iron;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_details_add);


        ImageView backButton = findViewById(R.id.backArrow);
        backButton.setVisibility(View.VISIBLE);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        ImageView dryCleanMinus = (ImageView) findViewById(R.id.dryCleanMinus);
        ImageView dryCleanPlus = (ImageView) findViewById(R.id.dryCleanPlus);
        final TextView dryCleanCount = (TextView) findViewById(R.id.dryCleanCount);



        ImageView washIronMinus = (ImageView) findViewById(R.id.washIronMinus);
        ImageView washIronPlus = (ImageView) findViewById(R.id.washIronPlus);
        final TextView washIronCount = (TextView) findViewById(R.id.washIronCount);

        ImageView ironingPlus = (ImageView) findViewById(R.id.ironingPlus);
        ImageView ironingMinus = (ImageView) findViewById(R.id.ironingMinus);
        final TextView ironingCount = (TextView) findViewById(R.id.ironingCount);





        ImageView iv_detail = (ImageView) findViewById(R.id.iv_detail);
        TextView addToBasketId = (TextView) findViewById(R.id.addToBasketId);
        String url = getIntent().getExtras().getString("url");
        catId=getIntent().getExtras().getInt("catId");
        catName=getIntent().getExtras().getString("catname");
        itemId=getIntent().getExtras().getInt("itemId");
        itemName=getIntent().getExtras().getString("itemname");

        dry= Almosky.getInst().getDrycleanList();
        wash=Almosky.getInst().getWashList();
        iron=Almosky.getInst().getIronList();

        if(null!=dry){

            for(int i=0;i<dry.size();i++){

                if(dry.get(i).getItemId().equals(itemId)){
                    dryCleanCount.setText(dry.get(i).getItemcount().toString());
                }

            }
        }
        if(null!=wash){

            for(int i=0;i<wash.size();i++){

                if(wash.get(i).getItemId().equals(itemId)){
                    washIronCount.setText(wash.get(i).getItemcount().toString());
                }

            }
        }

        if(null!=iron){

            for(int i=0;i<iron.size();i++){

                if(iron.get(i).getItemId().equals(itemId)){
                    ironingCount.setText(iron.get(i).getItemcount().toString());
                }

            }
        }



        Glide.with(this).load(url).into(iv_detail);
        addToBasketId.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(ItemDetailsAddActivity.this, CategoryListActivity.class);
                intent.putExtra("className", "ItemDetailsAddActivity");
                intent.putExtra("count", 1);
                intent.putExtra("price", "7");
                startActivity(intent);
            }
        });

        dryCleanMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int countDryClean = Integer.parseInt(dryCleanCount.getText().toString());
                if (countDryClean > 0) {
                    countDryClean = countDryClean - 1;
                    dryCleanCount.setText("" + countDryClean);
                    int totcount=Almosky.getInst().getCartcount()-1;
                    Almosky.getInst().setCartcount(totcount);
                    updateData(itemId,itemName,countDryClean,"dryclean");
                }
            }
        });
        dryCleanPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int countDryClean = Integer.parseInt(dryCleanCount.getText().toString());
                countDryClean = countDryClean + 1;
                dryCleanCount.setText("" + countDryClean);

                updateData(itemId,itemName,countDryClean,"dryclean");
            }
        });

        washIronMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int countWashIron = Integer.parseInt(washIronCount.getText().toString());
                if (countWashIron > 0) {
                    countWashIron = countWashIron - 1;
                    washIronCount.setText("" + countWashIron);
                    updateData(itemId,itemName,countWashIron,"washiron");
                }
            }
        });
        washIronPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int countWashIron = Integer.parseInt(washIronCount.getText().toString());
                countWashIron = countWashIron + 1;
                washIronCount.setText("" + countWashIron);
                updateData(itemId,itemName,countWashIron,"washiron");
            }
        });

        ironingMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int countIroning = Integer.parseInt(ironingCount.getText().toString());
                if (countIroning > 0) {
                    countIroning = countIroning - 1;
                    ironingCount.setText("" + countIroning);
                    updateData(itemId,itemName,countIroning,"iron");
                }
            }
        });
        ironingPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int countIroning = Integer.parseInt(ironingCount.getText().toString());
                countIroning = countIroning + 1;
                ironingCount.setText("" + countIroning);
                updateData(itemId,itemName,countIroning,"iron");
            }
        });

    }





    private void updateData(int itemId, String itemName, int count, String type) {



        if(type.equals("dryclean")){
            int isPresent=0;
            ArrayList<data.Detail.Item> drycleanList=Almosky.getInst().getDrycleanList();
            if(null!=drycleanList){


                for(int i=0;i<drycleanList.size();i++){
                    if(drycleanList.get(i).getItemId().equals(itemId)){
                       // drycleanList.get(i).setItemcount(count);
                        Almosky.getInst().getDrycleanList().get(i).setItemcount(count);
                        int amount= Integer.parseInt(Almosky.getInst().getDrycleanList().get(i).getAmount());
                        Almosky.getInst().getDrycleanList().get(i).setTotal(String.valueOf(amount*count));
                        isPresent=1;
                    }


                }
                if(isPresent==0){

                    ArrayList<data.Detail.Item> drylst=new ArrayList<>();

                    data obj=new data();
                    data.Detail detailobj=obj. new Detail();
                    detailobj.setType(type);

                    data.Detail.Item itemObj=detailobj. new Item();

                    itemObj.setItemId(itemId);
                    itemObj.setAmount("15");
                    itemObj.setItemName(itemName);
                    itemObj.setItemcount(count);

                    itemObj.setTotal(String.valueOf(Integer.parseInt("15")*count));
                    drylst.add(itemObj);

                    Almosky.getInst().setDrycleanList(drylst);

                }

            }else {


                data obj=new data();
                ArrayList<data.Detail.Item> drylst=new ArrayList<>();
            //    ArrayList<data.Detail.Item> items=new ArrayList<>();

                try{

                    //  JSONArray mainArray=new JSONArray();
                    //  JSONObject mainobj=new JSONObject();
                    data.Detail detailobj=obj. new Detail();
                    detailobj.setType(type);

                    data.Detail.Item itemObj=detailobj. new Item();

                    itemObj.setItemId(itemId);
                    itemObj.setAmount("15");
                    itemObj.setItemName(itemName);
                    itemObj.setItemcount(count);

                    itemObj.setTotal(String.valueOf(Integer.parseInt("15")*count));
                    drylst.add(itemObj);

                    Almosky.getInst().setDrycleanList(drylst);
                }catch (Exception e){

                    e.printStackTrace();
                }

            }
        }

        //washiron list
        else if(type.equals("washiron")){
            int isPresent=0;
            ArrayList<data.Detail.Item> washironList=Almosky.getInst().getWashList();
            if(null!=washironList){


                for(int i=0;i<washironList.size();i++){
                    if(washironList.get(i).getItemId().equals(itemId)){
                        washironList.get(i).setItemcount(count);
                        int amount= Integer.parseInt(Almosky.getInst().getWashList().get(i).getAmount());
                        Almosky.getInst().getWashList().get(i).setTotal(String.valueOf(amount*count));
                        isPresent=1;
                    }


                }
                if(isPresent==0){

                    ArrayList<data.Detail.Item> wlst=new ArrayList<>();
                    data obj=new data();
                    data.Detail detailobj=obj. new Detail();
                    detailobj.setType(type);

                    data.Detail.Item itemObj=detailobj. new Item();

                    itemObj.setItemId(itemId);
                    itemObj.setAmount("15");
                    itemObj.setItemName(itemName);
                    itemObj.setItemcount(count);
                    itemObj.setTotal(String.valueOf(Integer.parseInt("15")*count));

                    wlst.add(itemObj);

                    Almosky.getInst().setWashList(wlst);

                }

            }else {

                ArrayList<data.Detail.Item> wlst=new ArrayList<>();

                data obj=new data();
                //    ArrayList<data.Detail.Item> items=new ArrayList<>();

                try{

                    //  JSONArray mainArray=new JSONArray();
                    //  JSONObject mainobj=new JSONObject();
                    data.Detail detailobj=obj. new Detail();
                    detailobj.setType(type);

                    data.Detail.Item itemObj=detailobj. new Item();

                    itemObj.setItemId(itemId);
                    itemObj.setAmount("15");
                    itemObj.setItemName(itemName);
                    itemObj.setItemcount(count);

                    itemObj.setTotal(String.valueOf(Integer.parseInt("15")*count));
                    wlst.add(itemObj);

                    Almosky.getInst().setWashList(wlst);
                }catch (Exception e){

                    e.printStackTrace();
                }

            }
        }

        //iron

        else if(type.equals("iron")){
            int isPresent=0;
            ArrayList<data.Detail.Item> ironList=Almosky.getInst().getIronList();
            if(null!=ironList){


                for(int i=0;i<ironList.size();i++){
                    if(ironList.get(i).getItemId().equals(itemId)){
                        ironList.get(i).setItemcount(count);
                        int amount= Integer.parseInt(Almosky.getInst().getIronList().get(i).getAmount());
                        Almosky.getInst().getIronList().get(i).setTotal(String.valueOf(amount*count));
                        isPresent=1;
                    }


                }
                if(isPresent==0){
                    ArrayList<data.Detail.Item> ilst=new ArrayList<>();

                    data obj=new data();
                    data.Detail detailobj=obj. new Detail();
                    detailobj.setType(type);

                    data.Detail.Item itemObj=detailobj. new Item();

                    itemObj.setItemId(itemId);
                    itemObj.setAmount("25");
                    itemObj.setItemName(itemName);
                    itemObj.setItemcount(count);
                    itemObj.setTotal(String.valueOf(Integer.parseInt("25")*count));
                    ilst.add(itemObj);

                    Almosky.getInst().setIronList(ilst);

                }

            }else {

                ArrayList<data.Detail.Item> ilst=new ArrayList<>();

                data obj=new data();
                //    ArrayList<data.Detail.Item> items=new ArrayList<>();

                try{


                    //  JSONArray mainArray=new JSONArray();
                    //  JSONObject mainobj=new JSONObject();
                    data.Detail detailobj=obj. new Detail();
                    detailobj.setType(type);

                    data.Detail.Item itemObj=detailobj. new Item();

                    itemObj.setItemId(itemId);
                    itemObj.setAmount("20");
                    itemObj.setItemName(itemName);
                    itemObj.setItemcount(count);
                    itemObj.setTotal(String.valueOf(Integer.parseInt("20")*count));

                    ilst.add(itemObj);

                    Almosky.getInst().setIronList(ilst);
                }catch (Exception e){

                    e.printStackTrace();
                }

            }
        }


    }
}

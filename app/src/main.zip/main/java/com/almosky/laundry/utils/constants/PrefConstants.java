package com.almosky.laundry.utils.constants;


public interface PrefConstants {
    String isLogin = "isLogin";
    String email = "email";
    String name = "name";
    String area = "area";
    String street = "street";
    String land = "land";
    String building = "building";
    String flat = "flat";
    String phone = "phone";
    String emirate = "emirate";
    String pick = "pick";
    String deliv = "deliv";
    String home="home";
    String office="home";
    String uid="uid";



}

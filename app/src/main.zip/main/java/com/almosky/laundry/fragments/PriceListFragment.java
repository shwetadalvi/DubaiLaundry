package com.almosky.laundry.fragments;


import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.almosky.laundry.R;
import com.almosky.laundry.activity.neworder.HeadingView;
import com.almosky.laundry.activity.neworder.InfoView1;
import com.almosky.laundry.model.categoryItemPrice;
import com.almosky.laundry.model.categoryPriceList;
import com.mindorks.placeholderview.ExpandablePlaceHolderView;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class PriceListFragment extends Fragment {

    private static final String ARG_PAGE_NUMBER = "page_number";
    private ExpandablePlaceHolderView mExpandableView;
    ArrayList<categoryPriceList> categoryPriceListsArray = new ArrayList<>();
    private Button dryCleanButton;
    private Button washIronButton;
    private Button ironingButton;

    public PriceListFragment() {
        // Required empty public constructor
    }

    public static PriceListFragment newInstance(int page) {
        PriceListFragment fragment = new PriceListFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_PAGE_NUMBER, page);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_price_list, container, false);
        mExpandableView = (ExpandablePlaceHolderView) view.findViewById(R.id.expandableView);
        dryCleanButton = (Button) view.findViewById(R.id.dryCleanButton);
        washIronButton = (Button) view.findViewById(R.id.washIronButton);
        ironingButton = (Button) view.findViewById(R.id.ironingButton);
        dryCleanButton.setTransformationMethod(null);
        washIronButton.setTransformationMethod(null);
        ironingButton.setTransformationMethod(null);
        dryCleanButton.setBackgroundResource(R.drawable.ic_btn_blue_background);
        washIronButton.setBackgroundResource(R.drawable.ic_button_selectable);
        ironingButton.setBackgroundResource(R.drawable.ic_button_selectable);
        dryCleanButton.setTextColor(Color.WHITE);
        washIronButton.setTextColor(Color.BLACK);
        ironingButton.setTextColor(Color.BLACK);
        listeners();
        setData();
        addItemsToListView();
        return view;
    }

    private void listeners() {
        dryCleanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dryCleanButton.setBackgroundResource(R.drawable.ic_btn_blue_background);
                washIronButton.setBackgroundResource(R.drawable.ic_button_selectable);
                ironingButton.setBackgroundResource(R.drawable.ic_button_selectable);
                dryCleanButton.setTextColor(Color.WHITE);
                washIronButton.setTextColor(Color.BLACK);
                ironingButton.setTextColor(Color.BLACK);
            }
        });
        washIronButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dryCleanButton.setBackgroundResource(R.drawable.ic_button_selectable);
                washIronButton.setBackgroundResource(R.drawable.ic_btn_blue_background);
                ironingButton.setBackgroundResource(R.drawable.ic_button_selectable);
                dryCleanButton.setTextColor(Color.BLACK);
                washIronButton.setTextColor(Color.WHITE);
                ironingButton.setTextColor(Color.BLACK);
            }
        });
        ironingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dryCleanButton.setBackgroundResource(R.drawable.ic_button_selectable);
                washIronButton.setBackgroundResource(R.drawable.ic_button_selectable);
                ironingButton.setBackgroundResource(R.drawable.ic_btn_blue_background);
                dryCleanButton.setTextColor(Color.BLACK);
                washIronButton.setTextColor(Color.BLACK);
                ironingButton.setTextColor(Color.WHITE);
            }
        });
    }

    private void setData() {
        categoryPriceList obj1 = new categoryPriceList();
        obj1.setCategoryName("Traditional");
        categoryItemPrice sub1 = new categoryItemPrice();
        sub1.setName("Shirt");
        sub1.setFast("AED10.000");
        sub1.setNormal("AED5.000");
        ArrayList<categoryItemPrice> arrayList1 = new ArrayList<>();
        arrayList1.add(sub1);
        //  obj1.setCategoryItemPrices(arrayList1);

        categoryItemPrice sub2 = new categoryItemPrice();
        sub2.setName("Shirt");
        sub2.setFast("AED10.000");
        sub2.setNormal("AED5.000");
        // ArrayList<categoryItemPrice> arrayList2 = new ArrayList<>();
        arrayList1.add(sub2);
        obj1.setCategoryItemPrices(arrayList1);

        categoryPriceList obj2 = new categoryPriceList();
        obj2.setCategoryName("Tops");
        categoryItemPrice sub3 = new categoryItemPrice();
        sub3.setName("Top1");
        sub3.setFast("AED8.000");
        sub3.setNormal("AED4.000");
        ArrayList<categoryItemPrice> arrayList3 = new ArrayList<>();
        arrayList3.add(sub3);
        //  obj2.setCategoryItemPrices(arrayList3);

        categoryItemPrice sub4 = new categoryItemPrice();
        sub4.setName("Shirt");
        sub4.setFast("AED10.000");
        sub4.setNormal("AED5.000");
        //  ArrayList<categoryItemPrice> arrayList4 = new ArrayList<>();
        arrayList3.add(sub4);
        obj2.setCategoryItemPrices(arrayList3);
        categoryPriceListsArray.add(obj1);
        categoryPriceListsArray.add(obj2);

    }

    private void addItemsToListView() {
        for (int i = 0; i < categoryPriceListsArray.size(); i++) {


            mExpandableView.addView(new HeadingView(getActivity(), categoryPriceListsArray.get(i).getCategoryName(),"",2));
            for (int j = 0; j < categoryPriceListsArray.get(i).getCategoryItemPrices().size(); j++) {

                mExpandableView.addView(new InfoView1(getActivity(), categoryPriceListsArray.get(i).getCategoryItemPrices().get(j)));
            }
        }
    }

}

package com.almosky.laundry.activity.neworder;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.almosky.laundry.Almosky;
import com.almosky.laundry.R;
import com.almosky.laundry.activity.OrderConfirmationActivity;
import com.almosky.laundry.common.BaseActivity;
import com.almosky.laundry.model.categorydto;
import com.almosky.laundry.model.data;
import com.almosky.laundry.utils.api.ApiCalls;
import com.almosky.laundry.utils.constants.ApiConstants;
import com.google.gson.Gson;
import com.leo.simplearcloader.SimpleArcDialog;
import com.loopj.android.http.RequestParams;
import com.mindorks.placeholderview.ExpandablePlaceHolderView;

import java.util.ArrayList;


public class CategoryListActivity extends BaseActivity {

    private Context mContext;
    private ExpandablePlaceHolderView mExpandableView;
    private ExpandablePlaceHolderView.OnScrollListener mOnScrollListener;
    private boolean mIsLoadingMore = false;
    private boolean mNoMoreToLoad = false;
    ApiCalls apiCalls;
    SimpleArcDialog dialog;
    public static final int CATEGORIES = 10;
    private TextView title;
    private RelativeLayout bottomLayout;

    public TextView cartcount, cartamount;
    ArrayList<data.Detail.Item> dry;
    ArrayList<data.Detail.Item> wash;
    ArrayList<data.Detail.Item> iron;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if(Almosky.getInst().getOrderType().equals("easy")){
            Intent go=new Intent(CategoryListActivity.this,OrderConfirmationActivity.class);
            startActivity(go);
        }else {
            apiCalls = new ApiCalls();
            dialog = new SimpleArcDialog(this);




            ImageView backButton = findViewById(R.id.backArrow);
            backButton.setVisibility(View.VISIBLE);

            backButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            });

            bottomLayout = (RelativeLayout) findViewById(R.id.bottomLayout);

            dry = Almosky.getInst().getDrycleanList();
            wash = Almosky.getInst().getWashList();
            iron = Almosky.getInst().getIronList();

            if (null != dry || null != wash || null != iron) {
                checkCart();
            }


            bottomLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    Intent intent = new Intent(CategoryListActivity.this, OrderConfirmationActivity.class);

                    startActivity(intent);
                }
            });


            getCategoryList();
            mContext = this.getApplicationContext();
            mExpandableView = (ExpandablePlaceHolderView) findViewById(R.id.expandableView);

        }



//        setLoadMoreListener(mExpandableView);
    }

    private void checkCart() {

        int drycount = 0, dryamount = 0, washcount = 0, washamount = 0, ironcount = 0, ironamount = 0;


        if (null != dry) {
            for (int i = 0; i < dry.size(); i++) {
                drycount = drycount + dry.get(i).getItemcount();
                dryamount = dryamount + Integer.parseInt(dry.get(i).getTotal());
            }

        }
        if (null != wash) {
            for (int i = 0; i < wash.size(); i++) {

                washcount = washcount + wash.get(i).getItemcount();
                washamount = washamount + Integer.parseInt(wash.get(i).getTotal());
            }

        }
        if (null != iron) {

            for (int i = 0; i < iron.size(); i++) {
                ironcount = ironcount + iron.get(i).getItemcount();
                ironamount = ironamount + Integer.parseInt(iron.get(i).getTotal());
            }

        }

        int totalcount = drycount + washcount + ironcount;
        int totalamount = dryamount + washamount + ironamount;

        if (totalamount > 0 && totalcount > 0) {

            bottomLayout.setVisibility(View.VISIBLE);
            cartcount = (TextView) findViewById(R.id.tv_cartcount);
            cartamount = (TextView) findViewById(R.id.tv_cartamount);
            cartcount.setText("Your Basket(" + String.valueOf(totalcount).toString() + ")");
            cartamount.setText("AED" + String.valueOf(totalamount).toString());

        } else {

        }


    }

    @Override
    protected void onResume() {
        super.onResume();
        if (null != dry || null != wash || null != iron) {
            checkCart();
        }
    }

    private void setData() {


    }

    private void getCategoryList() {

        // if (!validate(view.getResources())) return;
        RequestParams params = new RequestParams();

        // params.put("LoginEmail", "admin@gmail.com");

        // params.put(ApiConstants.uid, appPrefes.getData(PrefConstants.uid));
        // params.put(ApiConstants.uid, 1);
        //  params.put(ApiConstants.status, "Pending");


        String url = ApiConstants.categoryUrl;
        apiCalls.callApiPost(CategoryListActivity.this, params, dialog, url, CATEGORIES);
    }


    @Override
    public void getResponse(String response, int requestId) {

        try {

            Gson gson = new Gson();
            final categorydto catList = gson.fromJson(response, categorydto.class);

            if (0 != catList.getDetail().size()) {
                for (int i = 0; i < catList.getDetail().size(); i++) {


                    mExpandableView.addView(new HeadingView(mContext, catList.getDetail().get(i).getCategoryName(),catList.getDetail().get(i).getCategoryIcons(),1));
                    for (int j = 0; j < catList.getDetail().get(i).getItems().size(); j++) {
                        mExpandableView.addView(new InfoView(mContext, catList.getDetail().get(i).getItems().get(j)));
                    }
                }

            }

        } catch (Exception e) {

        }

    }
/*
    private void setLoadMoreListener(ExpandablePlaceHolderView expandableView) {
        mOnScrollListener =
                new PlaceHolderView.OnScrollListener() {
                    @Override
                    public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                        super.onScrolled(recyclerView, dx, dy);
                        ExpandablePlaceHolderView.LayoutManager layoutManager = recyclerView.getLayoutManager();
                        if (layoutManager instanceof LinearLayoutManager) {
                            LinearLayoutManager linearLayoutManager = (LinearLayoutManager) layoutManager;
                            int totalItemCount = linearLayoutManager.getItemCount();
                            int lastVisibleItem = linearLayoutManager.findLastVisibleItemPosition();
                            if (!mIsLoadingMore
                                    && !mNoMoreToLoad
                                    && totalItemCount > 0
                                    && totalItemCount == lastVisibleItem + 1) {
                                mIsLoadingMore = true;
                                new Handler(Looper.getMainLooper()).post(new Runnable() {
                                    @Override
                                    public void run() {

                                        // do api call to fetch data

                                        // example of loading from file:
                                        for (Feed feed : Utils.loadFeeds(getApplicationContext())) {
                                            mExpandableView.addView(new HeadingView(mContext, feed.getHeading()));
                                            for (Info info : feed.getInfoList()) {
                                                mExpandableView.addView(new InfoView(mContext, info));
                                            }
                                        }
                                        mIsLoadingMore = false;
                                    }
                                });
                            }
                        }
                    }
                };
        expandableView.addOnScrollListener(mOnScrollListener);
    }  */
}
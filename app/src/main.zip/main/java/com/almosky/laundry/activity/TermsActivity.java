package com.almosky.laundry.activity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.almosky.laundry.R;
import com.almosky.laundry.utils.Utility;
import com.treebo.internetavailabilitychecker.InternetConnectivityListener;

public class TermsActivity extends AppCompatActivity {

    WebView terms;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_termscondition);



            terms = (WebView) findViewById(R.id.wv_terms);
            terms.requestFocus();


            WebSettings webSettings = terms.getSettings();
            terms.setWebViewClient(new WebViewClient());
            webSettings.setJavaScriptEnabled(true);


            terms.loadUrl("file:///android_asset/terms.html");









    }


}

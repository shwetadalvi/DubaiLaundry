package com.almosky.laundry.di.module;


import com.almosky.laundry.common.BaseActivity;

import dagger.Module;

@Module
public class ActivityModule {
    private BaseActivity baseActivity;

    public ActivityModule(BaseActivity baseActivity) {
        this.baseActivity = baseActivity;
    }

}

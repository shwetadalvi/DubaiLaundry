package com.almosky.laundry.common;

import android.support.v4.app.Fragment;


public class BaseFragment extends Fragment {


}

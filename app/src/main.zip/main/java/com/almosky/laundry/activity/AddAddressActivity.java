package com.almosky.laundry.activity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.almosky.laundry.Almosky;
import com.almosky.laundry.R;
import com.almosky.laundry.activity.neworder.AreaListActivity;
import com.almosky.laundry.common.BaseActivity;
import com.almosky.laundry.utils.AppPrefes;
import com.almosky.laundry.utils.api.ApiCalls;
import com.almosky.laundry.utils.constants.ApiConstants;
import com.almosky.laundry.utils.constants.Constants;
import com.almosky.laundry.utils.constants.PrefConstants;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.leo.simplearcloader.SimpleArcDialog;
import com.loopj.android.http.RequestParams;

import org.json.JSONException;
import org.json.JSONObject;

import cn.pedant.SweetAlert.SweetAlertDialog;


public class AddAddressActivity extends BaseActivity implements OnMapReadyCallback {

    public static final int AREA_LIST=123;
    private int PLACE_PICKER_REQUEST = 1;
    private GoogleMap _googleMap;
    private android.support.v7.widget.AppCompatEditText edtArea,block,house,floor,phone,aditional;
    ApiCalls apiCalls;
    SimpleArcDialog dialog;
    private AppPrefes appPrefes;
    android.support.v7.widget.AppCompatAutoCompleteTextView addresname;
    String lat;
    String lon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_add_address);

        appPrefes=new AppPrefes(this);
        apiCalls=new ApiCalls();
        dialog=new SimpleArcDialog(this);

        ImageView backButton = findViewById(R.id.backArrow);
        backButton.setVisibility(View.VISIBLE);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        ImageView pin = (ImageView) findViewById(R.id.pin);
        pin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PlacePicker.IntentBuilder builder = new PlacePicker.IntentBuilder();
                try {
                    startActivityForResult(builder.build(AddAddressActivity.this), PLACE_PICKER_REQUEST);
                } catch (GooglePlayServicesRepairableException | GooglePlayServicesNotAvailableException e) {
                    System.out.println("EXCEPTION============================ " + e);
                    e.printStackTrace();
                }

            }
        });
        //edtArea=(android.support.v7.widget.AppCompatEditText)findViewById(R.id.edtArea);
        addresname=(android.support.v7.widget.AppCompatAutoCompleteTextView)findViewById(R.id.edtAddressName);
        edtArea=(android.support.v7.widget.AppCompatEditText)findViewById(R.id.edtArea);
        block=(android.support.v7.widget.AppCompatEditText)findViewById(R.id.edtBlock);
        house=(android.support.v7.widget.AppCompatEditText)findViewById(R.id.edtHouse);
        floor=(android.support.v7.widget.AppCompatEditText)findViewById(R.id.edtFloor);
        aditional=(android.support.v7.widget.AppCompatEditText)findViewById(R.id.edtAdditional);
        phone=(android.support.v7.widget.AppCompatEditText)findViewById(R.id.edtPhone);


        edtArea.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AddAddressActivity.this, AreaListActivity.class);
                startActivityForResult(intent, AREA_LIST);
            }
        });
        Button btnStoreAddress=(Button)findViewById(R.id.btnStoreAddress);
        btnStoreAddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                addNewAddress();
            }
        });


    }

    private void addNewAddress() {

        // if (!validate(view.getResources())) return;
        RequestParams params = new RequestParams();

        params.put(Constants.email, appPrefes.getData(PrefConstants.email));
        params.put("addressname", addresname.getText().toString());
        params.put("area", edtArea.getText().toString());
        params.put("block", block.getText().toString());
        params.put("house", house.getText().toString());
        params.put("floor", floor.getText().toString());
        params.put("mobile", phone.getText().toString());
        params.put("additional",aditional.getText().toString());
        params.put("latitude",lat);
        params.put("longitude",lat);



        String url = ApiConstants.addAddressUrl;
        apiCalls.callApiPost(AddAddressActivity.this, params, dialog, url,7);

    }


    @Override
    public void getResponse(String response, int requestId) {
        try{

            String object= new String(response);
            JSONObject jsonObject = new JSONObject(object);
            String result = jsonObject.getString("status");

            if(result.equals("true"))
            {
                new SweetAlertDialog(AddAddressActivity.this, SweetAlertDialog.NORMAL_TYPE)
                        .setTitleText("Success")
                        .setContentText("Success")
                        .setConfirmText("Ok")
                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {



                                sDialog.dismissWithAnimation();

                                Intent go=new Intent(AddAddressActivity.this, AddressListActivity.class);
                                go.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK |Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                startActivity(go);


                            }
                        })
                        .show();
                // Toast.makeText(getApplicationContext(),"success",Toast.LENGTH_LONG).show();
            }
        } catch (JSONException e) {
            Toast.makeText(getApplicationContext(), "msg", Toast.LENGTH_LONG).show();
        }

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        LatLng sydney = new LatLng(-33.852, 151.211);
        _googleMap =googleMap;
        googleMap.addMarker(new MarkerOptions().position(sydney)
                .title("Marker in Sydney"));
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PLACE_PICKER_REQUEST) {
            if (resultCode == RESULT_OK) {
                Place place = PlacePicker.getPlace(data, this);
                StringBuilder stBuilder = new StringBuilder();
                String placename = String.format("%s", place.getName());
               lat = String.valueOf(place.getLatLng().latitude);
                lon = String.valueOf(place.getLatLng().longitude);
                String address = String.format("%s", place.getAddress());
                stBuilder.append("Name: ");
                stBuilder.append(placename);
                stBuilder.append("\n");
                stBuilder.append("Latitude: ");
                stBuilder.append(lat);
                stBuilder.append("\n");
                stBuilder.append("Logitude: ");
                stBuilder.append(lon);
                stBuilder.append("\n");
                stBuilder.append("Address: ");
                stBuilder.append(address);
                System.out.println("ADDRESS================ " + stBuilder.toString());
                LatLng sydney = new LatLng(place.getLatLng().latitude, place.getLatLng().longitude);
                _googleMap.addMarker(new MarkerOptions().position(sydney)
                        .title(address));
                _googleMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
            }
        }


        else if (requestCode == AREA_LIST) {
            String selectedArea = data.getStringExtra("selectedArea");
            edtArea.setText(selectedArea);
        }


    }
}

package com.almosky.laundry.di.component;


import com.almosky.laundry.common.BaseActivity;
import com.almosky.laundry.di.scope.ActivityScope;
import com.almosky.laundry.utils.AppPrefes;
import com.almosky.laundry.utils.UtilsPref;

import dagger.Component;

@ActivityScope
@Component(dependencies = AppComponent.class)
public interface ActivityComponent extends AppComponent {
    void inject(BaseActivity baseActivity);

    void inject(UtilsPref utilsPref);

    void inject(AppPrefes appPrefes);
}
package com.almosky.laundry.viewholder;

import android.content.Context;

import android.support.v7.widget.RecyclerView;
import android.view.View;

public class PickUpTimeRecyclerViewHolders extends RecyclerView.ViewHolder {

//    UserActionCountItemBinding binding;

    public PickUpTimeRecyclerViewHolders(View itemView, Context context) {
        super(itemView);

//        binding = DataBindingUtil.bind(itemView);
    }

    public void bind() {
//        binding.setDetails(detailsBean);
    }


}

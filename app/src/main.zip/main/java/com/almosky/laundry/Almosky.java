package com.almosky.laundry;


import com.almosky.laundry.model.data;

import java.util.ArrayList;

public class Almosky {

    public static Almosky inst;


    public ArrayList<data.Detail.Item> drycleanList;
    public ArrayList<data.Detail.Item> ironList;
    public ArrayList<data.Detail.Item> washList;

    public String orderType;
    public String address;

    public String pickuptime;
    public String deliverytime;
    public String deliverydate;
    public String pickupdate;
    public int pickserviceType;
    public int addressId;
    public int delserviceType;

    public int serviceId;
    public int cartcount;
    public int cartamount;

    public String addressType; // 0 represents normal address, 1 represents address for new order

    private Almosky(){

    }


    public static Almosky getInst(){
        if(inst==null){
            inst=new Almosky();
        }
        return  inst;
    }


    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getAddressId() {
        return addressId;
    }

    public void setAddressId(int addressId) {
        this.addressId = addressId;
    }

    public String getAddressType() {
        return addressType;
    }

    public void setAddressType(String addressType) {
        this.addressType = addressType;
    }

    public String getPickuptime() {
        return pickuptime;
    }

    public void setPickuptime(String pickuptime) {
        this.pickuptime = pickuptime;
    }

    public String getDeliverytime() {
        return deliverytime;
    }

    public void setDeliverytime(String deliverytime) {
        this.deliverytime = deliverytime;
    }

    public String getDeliverydate() {
        return deliverydate;
    }

    public void setDeliverydate(String deliverydate) {
        this.deliverydate = deliverydate;
    }

    public String getPickupdate() {
        return pickupdate;
    }

    public void setPickupdate(String pickupdate) {
        this.pickupdate = pickupdate;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public int getPickserviceType() {
        return pickserviceType;
    }

    public void setPickserviceType(int pickserviceType) {
        this.pickserviceType = pickserviceType;
    }

    public int getDelserviceType() {
        return delserviceType;
    }

    public void setDelserviceType(int delserviceType) {
        this.delserviceType = delserviceType;
    }

    public int getCartcount() {
        return cartcount;
    }


    public int getServiceId() {
        return serviceId;
    }

    public void setServiceId(int serviceId) {
        this.serviceId = serviceId;
    }

    public void setCartcount(int cartcount) {
        this.cartcount = cartcount;
    }

    public int getCartamount() {
        return cartamount;
    }

    public void setCartamount(int cartamount) {
        this.cartamount = cartamount;
    }

    public ArrayList<data.Detail.Item> getDrycleanList() {
        return drycleanList;
    }

    public void setDrycleanList(ArrayList<data.Detail.Item> drycleanList) {
        this.drycleanList = drycleanList;
    }

    public ArrayList<data.Detail.Item> getIronList() {
        return ironList;
    }

    public void setIronList(ArrayList<data.Detail.Item> ironList) {
        this.ironList = ironList;
    }

    public ArrayList<data.Detail.Item> getWashList() {
        return washList;
    }

    public void setWashList(ArrayList<data.Detail.Item> washList) {
        this.washList = washList;
    }
}

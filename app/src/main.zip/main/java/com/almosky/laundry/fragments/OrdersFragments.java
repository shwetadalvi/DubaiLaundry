package com.almosky.laundry.fragments;


import android.content.Intent;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.almosky.laundry.Almosky;
import com.almosky.laundry.R;
import com.almosky.laundry.activity.SignupOrLoginActivity;
import com.almosky.laundry.activity.neworder.OrdertypeActivity;
import com.almosky.laundry.utils.AppPrefes;
import com.almosky.laundry.utils.constants.PrefConstants;


/**
 * A simple {@link Fragment} subclass.
 */
public class OrdersFragments extends Fragment {

    private static final String ARG_PAGE_NUMBER = "page_number";
    AppPrefes appPrefes;

    public OrdersFragments() {
        // Required empty public constructor
    }

    public static OrdersFragments newInstance(int page) {
        OrdersFragments fragment = new OrdersFragments();
        Bundle args = new Bundle();
        args.putInt(ARG_PAGE_NUMBER, page);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_orders_fragments, container, false);

        appPrefes=new AppPrefes(getActivity());

        ConstraintLayout easyOrderLyt = (ConstraintLayout) view.findViewById(R.id.easyOrderLyt);
        easyOrderLyt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(appPrefes.getBoolData(PrefConstants.isLogin)){
                    Almosky.getInst().setOrderType("easy");
                    Almosky.getInst().setAddressType("0");
                    startActivity(new Intent(getActivity(), OrdertypeActivity.class));
                }else {
                    startActivity(new Intent(getActivity(), SignupOrLoginActivity.class));
                }

            }
        });
        ConstraintLayout normalOrderLyt = (ConstraintLayout) view.findViewById(R.id.normalOrderLyt);
        normalOrderLyt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                appPrefes.saveBoolData(PrefConstants.isLogin, true);

                if(appPrefes.getBoolData(PrefConstants.isLogin)){
                    Almosky.getInst().setAddressType("1");
                    Almosky.getInst().setOrderType("enter");
                    startActivity(new Intent(getActivity(), OrdertypeActivity.class));
                }else {
                    startActivity(new Intent(getActivity(), SignupOrLoginActivity.class));
                }

            }
        });
        return view;
    }

}

package com.almosky.laundry.adapter;

import android.content.Context;
import android.graphics.Color;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import com.almosky.laundry.Almosky;
import com.almosky.laundry.R;
import com.almosky.laundry.viewholder.PickUpTimeRecyclerViewHolders;

import java.util.List;

public class PickUpTimeRecyclerViewAdapter extends RecyclerView.Adapter<PickUpTimeRecyclerViewHolders> {

    private List<String> _timeArray;
    //    private List<UserLogCountResponse.DetailsBean> itemList;
    private Context context;
    private int row_index;
    private String _activity;


    public PickUpTimeRecyclerViewAdapter(Context context, List<String> timeArray,String activity) {
//        this.itemList = itemList;
        this.context = context;
        _timeArray = timeArray;
        _activity=activity;
    }

    @Override
    public PickUpTimeRecyclerViewHolders onCreateViewHolder(ViewGroup parent, int viewType) {

        View layoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.pickup_time_item, null);
        PickUpTimeRecyclerViewHolders rcv = new PickUpTimeRecyclerViewHolders(layoutView, context);
        return rcv;
    }

    @Override
    public void onBindViewHolder(PickUpTimeRecyclerViewHolders holder, final int position) {
//        UserLogCountResponse.DetailsBean status = itemList.get(position);
//        holder.bind(status);
        ConstraintLayout rowTime = holder.itemView.findViewById(R.id.rowTime);
        TextView time = holder.itemView.findViewById(R.id.time);
        time.setText(_timeArray.get(position));
        if(position==0) {

            if (_activity.equals("pickup")) {
                Almosky.getInst().setPickuptime(_timeArray.get(position));
            }
            if (_activity.equals("delivery")) {
                Almosky.getInst().setDeliverytime(_timeArray.get(position));
            }
        }
        rowTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                row_index = position;
                if(_activity.equals("pickup")){
                    Almosky.getInst().setPickuptime(_timeArray.get(position));
                }
                if(_activity.equals("delivery")){
                    Almosky.getInst().setDeliverytime(_timeArray.get(position));
                }

                notifyDataSetChanged();
            }
        });
        if (row_index == position) {
            rowTime.setBackgroundColor(Color.parseColor("#ff3d5afe"));
            time.setTextColor(Color.parseColor("#ffffff"));
        } else {
            rowTime.setBackgroundColor(Color.parseColor("#ffffff"));
            time.setTextColor(Color.parseColor("#000000"));
        }
    }


    @Override
    public int getItemCount() {
//        if (null == itemList)
//            return 0;
//        else
//            return this.itemList.size();
        return _timeArray.size();
    }
}

package com.almosky.laundry.model;

public class MainModel {
}

package com.almosky.laundry.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;


import com.almosky.laundry.R;
import com.almosky.laundry.adapter.AddressListAdapter;
import com.almosky.laundry.adapter.OrderListAdapter;
import com.almosky.laundry.common.BaseActivity;
import com.almosky.laundry.model.Addressdto;
import com.almosky.laundry.model.OrderListdto;
import com.almosky.laundry.utils.AppPrefes;
import com.almosky.laundry.utils.api.ApiCalls;
import com.almosky.laundry.utils.constants.ApiConstants;
import com.almosky.laundry.utils.constants.PrefConstants;
import com.google.gson.Gson;
import com.leo.simplearcloader.SimpleArcDialog;
import com.loopj.android.http.RequestParams;

public class OrderDetailsActivity extends BaseActivity {
    AppPrefes appPrefes;
    ApiCalls apiCalls;
    SimpleArcDialog dialog;
    RecyclerView rvOrders;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orderlist);
        rvOrders=(RecyclerView)findViewById(R.id.rvorderList);
        ImageView backButton = findViewById(R.id.backArrow);
        backButton.setVisibility(View.VISIBLE);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        getOrders();
    }

    private void getOrders() {

        // if (!validate(view.getResources())) return;
        RequestParams params = new RequestParams();

        params.put("email",  appPrefes.getData(PrefConstants.email));
        params.put("status",  "All");

        // params.put(ApiConstants.uid, appPrefes.getData(PrefConstants.uid));
        // params.put(ApiConstants.uid, 1);
        //  params.put(ApiConstants.status, "Pending");


        String url = ApiConstants.orderListUrl;
        apiCalls.callApiPost(OrderDetailsActivity.this, params, dialog, url, 1);


    }

    @Override
    public void getResponse(String response, int requestId) {

        try{
            Gson gson = new Gson();
            final OrderListdto orderList = gson.fromJson(response, OrderListdto.class);
            OrderListAdapter mAdapter = new OrderListAdapter(OrderDetailsActivity.this, orderList.getResult());
            RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
            rvOrders.setLayoutManager(mLayoutManager);
            rvOrders.setItemAnimator(new DefaultItemAnimator());
            rvOrders.setAdapter(mAdapter);


        }catch (Exception e){

        }

    }
}

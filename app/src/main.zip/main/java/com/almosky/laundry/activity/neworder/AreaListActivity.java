package com.almosky.laundry.activity.neworder;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ImageButton;

import com.almosky.laundry.R;
import com.almosky.laundry.activity.AddAddressActivity;
import com.almosky.laundry.adapter.AreasListAdapter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AreaListActivity extends AppCompatActivity {

    private RecyclerView listAreas;
    List<String> areaArray = new ArrayList<>(Arrays.asList("Academic City", "Al Barari", "Barsha 1", "Barsha 2", "Barsha 3", "Barsha south"));
    private TextInputEditText edtSearch;
    private ImageButton btnClear;
    private AreasListAdapter mAdapter;
    private boolean isRemove;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_areas);
        listAreas = findViewById(R.id.listAreas);
        edtSearch = findViewById(R.id.edtSearch);
        btnClear = findViewById(R.id.btnClear);
        mAdapter = new AreasListAdapter(AreaListActivity.this, areaArray);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        listAreas.setLayoutManager(mLayoutManager);
        listAreas.setItemAnimator(new DefaultItemAnimator());
        listAreas.setAdapter(mAdapter);
        addTextListener();
        listeners();
    }

    private void listeners() {
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isRemove = true;
                edtSearch.setText("");
            }
        });
    }

    private void addTextListener() {
        edtSearch.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            public void onTextChanged(CharSequence query, int start, int before, int count) {
                if (!isRemove)
                    if (edtSearch.getText().toString().isEmpty()) {
                        btnClear.performClick();
                        return;
                    }
                isRemove = false;
                if (query.length() > 0)
                    btnClear.setVisibility(View.VISIBLE);
                else
                    btnClear.setVisibility(View.GONE);
                query = query.toString().toLowerCase().trim();
                List<String> filteredListjsonArray = new ArrayList<>();
                if (null != areaArray) {
                    for (int j = 0; j < areaArray.size(); j++) {
                        String itemObj = areaArray.get(j);
                        if (null != itemObj) {
                            if (itemObj.toLowerCase().contains(query)) {
                                filteredListjsonArray.add(itemObj);
                            }
                        }

                    }
                }
                if (filteredListjsonArray.size() > 0) {
                    listAreas.setVisibility(View.VISIBLE);
                } else {
                    listAreas.setVisibility(View.GONE);
                }
                mAdapter = new AreasListAdapter(AreaListActivity.this, filteredListjsonArray);
                listAreas.setAdapter(mAdapter);
            }
        });
    }

    public void setSelectedItem(String selectedArea) {
        Intent intent = new Intent();
        intent.putExtra("selectedArea", selectedArea);
        setResult(AddAddressActivity.AREA_LIST, intent);
        finish();
    }
}

package com.almosky.laundry.viewholder;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;

public class PickUpDateRecyclerViewHolders extends RecyclerView.ViewHolder {
    private final Context _ctx;


//    UserActionCountItemBinding binding;

    public PickUpDateRecyclerViewHolders(View itemView, Context context) {
        super(itemView);

        _ctx =context;
//        binding = DataBindingUtil.bind(itemView);
    }

    public void bind() {


//        binding.setDetails(detailsBean);
    }


}
